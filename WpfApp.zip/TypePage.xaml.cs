﻿// TypePage.xaml.cs - WPF에서 Shell로 enum 요청하고 버튼 동적 생성
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace WpfApp
{
    public partial class TypePage : Page
    {
        public TypePage()
        {
            InitializeComponent();
            GenerateButtonsFromEnum("0"); // 0은 CarType_Q에 해당
        }

        private void GenerateButtonsFromEnum(string enumTypeCode)
        {
            UdpHelper.SendMessage("enum_request:" + enumTypeCode);
            string response = UdpHelper.ReceiveMessage(); // "1:Sedan,2:SUV,3:Truck" 같은 형식

            // 텍스트(TextBlock)를 유지하고 나머지 요소(Button)만 제거
            if (ButtonContainer.Children.Count > 1)
            {
                ButtonContainer.Children.RemoveRange(1, ButtonContainer.Children.Count - 1);
            }

            foreach (var item in response.Split(','))
            {
                var parts = item.Split(':');
                if (parts.Length != 2) continue;

                string value = parts[0];
                string label = parts[1];

                var btn = new Button
                {
                    Content = label,
                    Tag = value,
                    Height = 50,
                    FontSize = 18,
                    Margin = new Thickness(0, 0, 0, 15)
                };

                btn.Click += (s, e) =>
                {
                    UdpHelper.SendMessage((string)((Button)s).Tag);
                    NavigationService?.Navigate(new EnginePage());
                };

                ButtonContainer.Children.Add(btn);
            }
        }
    }
}