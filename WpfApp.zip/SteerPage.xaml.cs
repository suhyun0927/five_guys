﻿// SteerPage.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace WpfApp
{
    public partial class SteerPage : Page
    {
        public SteerPage()
        {
            InitializeComponent();
            GenerateButtonsFromEnum("3"); // SteeringSystem_Q
        }

        private void GenerateButtonsFromEnum(string enumTypeCode)
        {
            UdpHelper.SendMessage("enum_request:" + enumTypeCode);
            string response = UdpHelper.ReceiveMessage();

            // 텍스트(TextBlock)를 유지하고 나머지 요소(Button)만 제거
            if (ButtonContainer.Children.Count > 1)
            {
                ButtonContainer.Children.RemoveRange(1, ButtonContainer.Children.Count - 1);
            }

            foreach (var item in response.Split(','))
            {
                var parts = item.Split(':');
                if (parts.Length != 2) continue;

                string value = parts[0];
                string label = parts[1];

                var btn = new Button
                {
                    Content = label,
                    Tag = value,
                    Height = 50,
                    FontSize = 18,
                    Margin = new Thickness(0, 0, 0, 15)
                };

                btn.Click += (s, e) =>
                {
                    UdpHelper.SendMessage((string)((Button)s).Tag);
                    NavigationService?.Navigate(new TestPage());
                };

                ButtonContainer.Children.Add(btn);
            }
        }
    }
}
