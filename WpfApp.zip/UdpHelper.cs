﻿// UdpHelper.cs - Shell과 UDP 통신 도우미
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace WpfApp
{
    public static class UdpHelper
    {
        private const string UdpIp = "127.0.0.1";
        private const int UdpPort = 12345;
        private static readonly UdpClient udpClient = new UdpClient();

        public static void SendMessage(string message)
        {
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(message);
                udpClient.Send(data, data.Length, UdpIp, UdpPort);
            }
            catch (Exception ex)
            {
                Console.WriteLine("UDP 전송 오류: " + ex.Message);
            }
        }

        public static string ReceiveMessage()
        {
            try
            {
                IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
                udpClient.Client.ReceiveTimeout = 1000; // 1초 대기 후 반환
                byte[] received = udpClient.Receive(ref remoteEP);
                return Encoding.UTF8.GetString(received);
            }
            catch (Exception ex)
            {
                Console.WriteLine("UDP 수신 오류: " + ex.Message);
                return string.Empty;
            }
        }
    }
}